# dt-core

Status:
[![Build Status](https://ci.duckietown.org/buildStatus/icon?job=Docker+Autobuild+-+daffy+-+dt-core)](https://ci.duckietown.org/job/Docker%20Autobuild%20-%20daffy%20-%20dt-core/)
[![Docker Hub](https://img.shields.io/docker/pulls/duckietown/dt-core.svg)](https://hub.docker.com/r/duckietown/dt-core)

Code that runs the core stack on the Duckiebot in ROS
