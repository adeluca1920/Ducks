from dt_shell import UserError

__all__ = ["InvalidUserInput"]


class InvalidUserInput(UserError):
    pass
