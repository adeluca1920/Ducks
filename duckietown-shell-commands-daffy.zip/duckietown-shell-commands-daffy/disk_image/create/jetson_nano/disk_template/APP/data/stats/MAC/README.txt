Two files will be created in this directory, called "eth0" and "wlan0",
and they will contain the MAC addresses of the two interfaces.

If they are not there, it means that the boot process was interrupted.