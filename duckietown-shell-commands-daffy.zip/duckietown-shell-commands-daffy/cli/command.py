import argparse
import json
import os
import shutil
import subprocess
import uuid

from dt_shell import DTCommandAbs, DTShell, dtslogger
from utils.docker_utils import DEFAULT_MACHINE
from utils.dtproject_utils import CANONICAL_ARCH
from utils.duckietown_utils import get_distro_version
from utils.misc_utils import sanitize_hostname

DEFAULT_IMAGE = "duckietown/dt-gui-tools:{distro}-{arch}"
DEFAULT_RUNTIME = "docker"
DEFAULT_VOLUMES = ["/var/run/avahi-daemon/socket"]


class DTCommand(DTCommandAbs):
    help = "Easy way to run CLI commands inside a Duckietown ROS environment"

    @staticmethod
    def command(shell: DTShell, args):
        if "--help" in args or "-h" in args:
            print(
                "\nRun the command <command> inside a Duckietown ROS environment as:"
                "\n\n\tdts %s [options] -- [command]\n\n----\n" % DTCommand.name
            )
        # configure arguments
        parser = argparse.ArgumentParser()
        parser.add_argument(
            "-H",
            "--machine",
            default=None,
            help="Docker socket or hostname where to run the image",
        )
        parser.add_argument("-i", "--image", default=None, help="Docker image to run the command in")
        parser.add_argument(
            "--runtime", default=DEFAULT_RUNTIME, type=str, help="Docker runtime to use to run the container"
        )
        parser.add_argument(
            "-X",
            dest="use_x_docker",
            default=False,
            action="store_true",
            help="Use x-docker as runtime (needs to be installed separately)",
        )
        parser.add_argument("-M", "--master", default=None, type=str, help="Hostname of the ROS Master node")
        parser.add_argument(
            "-e",
            "--env",
            dest="environ",
            default=[],
            action="append",
            help="Environment variables to set inside the environment container",
        )
        parser.add_argument(
            "-A",
            "--argument",
            dest="arguments",
            default=[],
            action="append",
            help="Additional docker arguments for the environment container",
        )
        parser.add_argument("command", nargs="*", default=[])
        parsed, _ = parser.parse_known_args(args=args)
        # ---
        # sanitize hostname
        if parsed.machine is not None:
            parsed.machine = sanitize_hostname(parsed.machine)
        else:
            parsed.machine = DEFAULT_MACHINE
        # docker runtime and use_x_docker are mutually exclusive
        if parsed.use_x_docker and parsed.runtime != DEFAULT_RUNTIME:
            raise ValueError("You cannot use --runtime and -X at the same time.")
        # docker arguments
        docker_arguments = [] if not parsed.arguments else list(map(lambda s: "--%s" % s, parsed.arguments))
        # x-docker runtime
        if parsed.use_x_docker:
            parsed.runtime = "x-docker"
            docker_arguments += ["--privileged"]
        # check runtime
        if shutil.which(parsed.runtime) is None:
            raise ValueError('Docker runtime binary "{}" not found!'.format(parsed.runtime))
        # environ
        environ = []
        # ROS master
        if parsed.master:
            master = sanitize_hostname(parsed.master)
            environ += ["--env", f"ROS_MASTER_URI=http://{master}:11311"]
            environ += ["--env", f"VEHICLE_NAME={parsed.master}"]
        # environment variables
        environ += list(map(lambda e: "--env=%s" % e, parsed.environ))
        # check command
        if not parsed.command:
            parsed.command = ["/bin/bash"]
        # get info about docker endpoint
        dtslogger.info("Retrieving info about Docker endpoint...")
        epoint = _run_cmd(
            ["docker", "-H=%s" % parsed.machine, "info", "--format", "{{json .}}"],
            get_output=True,
            print_output=False,
        )
        epoint = json.loads(epoint)
        if "ServerErrors" in epoint:
            dtslogger.error("\n".join(epoint["ServerErrors"]))
            return
        if epoint["Architecture"] not in CANONICAL_ARCH:
            raise ValueError("The architecture %s is not supported" % epoint["Architecture"])
        endpoint_arch = CANONICAL_ARCH[epoint["Architecture"]]
        # volumes
        volumes = ["--volume=%s:%s" % (v, v) for v in DEFAULT_VOLUMES if os.path.exists(v)]
        # compile image name
        image = (
            parsed.image
            if parsed.image
            else DEFAULT_IMAGE.format(distro=get_distro_version(shell), arch=endpoint_arch)
        )
        # print info
        dtslogger.info("Running command [%s]..." % " ".join(parsed.command))
        print("------>")
        # run container with command inside
        _run_cmd(
            [
                parsed.runtime,
                "-H=%s" % parsed.machine,
                "run",
                "-it",
                "--rm",
                "--net=host",
                "--name",
                str(uuid.uuid4())[:8],
            ]
            + environ
            + volumes
            + docker_arguments
            + [image]
            + parsed.command,
            suppress_errors=True,
        )
        # ---
        print("<------")

    @staticmethod
    def complete(shell, word, line):
        return [
            # non-exhaustive list of common ROS commands
            # - ros* cli
            "rosrun",
            "rosmsg",
            "rostopic",
            "rosnode",
            "rosservice",
            "rossrv",
            "rosparam",
            # - rqt* cli
            "rqt",
            "rqt_image_view",
            "rqt_graph",
            # - others
            "rviz",
        ]


def _run_cmd(cmd, get_output=False, print_output=False, suppress_errors=False, shell=False):
    if shell:
        cmd = " ".join([str(s) for s in cmd])
    dtslogger.debug("$ %s" % cmd)
    if get_output:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=shell)
        proc.wait()
        if proc.returncode != 0:
            if not suppress_errors:
                msg = "The command {} returned exit code {}".format(cmd, proc.returncode)
                dtslogger.error(msg)
                raise RuntimeError(msg)
        out = proc.stdout.read().decode("utf-8").rstrip()
        if print_output:
            print(out)
        return out
    else:
        try:
            subprocess.check_call(cmd, shell=shell)
        except subprocess.CalledProcessError as e:
            if not suppress_errors:
                raise e
