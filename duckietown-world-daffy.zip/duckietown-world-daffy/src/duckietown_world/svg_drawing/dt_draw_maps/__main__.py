from .draw_maps import draw_maps_main

draw_maps_main()
