
Do not use these files directly.

These files are only here to be converted to the duckietown-world format.


The converted map is in ../gd1/maps/robotarium1.yaml
