from dt_robot_rest_api.constants import HTTP_PORTS
from dt_robot_utils import RobotType


blueprints = []
HTTP_PORT = HTTP_PORTS[RobotType.TRAFFIC_LIGHT]
