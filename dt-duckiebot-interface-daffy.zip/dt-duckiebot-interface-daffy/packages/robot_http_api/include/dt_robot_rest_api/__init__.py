"""
The `robot_rest_api` library provides an HTTP API to the robot.


"""

from .api import RobotRestAPI
