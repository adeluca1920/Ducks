"""

    rgb_led
    -------

    Describe `rgb_leb` here...

    .. autoclass:: rgb_led.RGB_LED

"""

from .rgb_led import RGB_LED
