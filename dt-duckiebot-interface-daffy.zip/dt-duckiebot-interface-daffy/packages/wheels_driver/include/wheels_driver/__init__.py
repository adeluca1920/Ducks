"""
The wheels driver consists of a single class that handles the communication with the wheel drivers.

.. autoclass:: wheels_driver.DaguWheelsDriver

"""
from .dagu_wheels_driver import DaguWheelsDriver
