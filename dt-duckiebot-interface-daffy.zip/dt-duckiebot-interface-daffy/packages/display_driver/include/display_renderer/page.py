from duckietown_msgs.msg import DisplayFragment as DisplayFragmentMsg

ALL_PAGES = DisplayFragmentMsg.PAGE_ALL
