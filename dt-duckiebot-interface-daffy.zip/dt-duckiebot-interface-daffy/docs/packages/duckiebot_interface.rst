duckiebot\_interface package
============================

The `duckiebot_interface` package is a wrapper around the all nodes in `duckiebot-interface`. It
contains a single launch file that starts all the nodes in `duckiebot-interface`.
