wheels\_driver package
======================

.. contents::

The `wheels_driver` package handles the actual execution of motor commands by the motors via
a motor driver. This is done by the :obj:`WheelsDriverNode`.

WheelsDriverNode
----------------

.. autoclass:: dt_duckiebot_interface.WheelsDriverNode

Included libraries
------------------

wheels_driver
^^^^^^^^^^^^^

.. automodule:: wheels_driver
