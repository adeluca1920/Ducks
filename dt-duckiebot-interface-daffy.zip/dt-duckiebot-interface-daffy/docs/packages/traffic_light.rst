traffic\_light package
======================

.. contents::

The `traffic_light` package contains a single node (`TrafficLightNode`) that is responsible for controlling the LEDs of a traffic light. You can find details about its use and configuration bellow.

TrafficLightNode
----------------

.. autoclass:: dt_duckiebot_interface.TrafficLightNode
