from .squeezenet import Squeezenet
